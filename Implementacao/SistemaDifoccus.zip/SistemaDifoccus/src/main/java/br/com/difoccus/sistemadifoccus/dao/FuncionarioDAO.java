package br.com.difoccus.sistemadifoccus.dao;

import br.com.difoccus.sistemadifoccus.modelo.Funcionario;
import org.hibernate.Query;
import org.hibernate.Session;

public class FuncionarioDAO extends GenericDAO<Funcionario> {
    
}