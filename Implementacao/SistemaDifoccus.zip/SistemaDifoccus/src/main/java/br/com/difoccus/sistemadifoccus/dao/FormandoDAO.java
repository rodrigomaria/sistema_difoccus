package br.com.difoccus.sistemadifoccus.dao;

import br.com.difoccus.sistemadifoccus.modelo.Formando;

public class FormandoDAO  extends  GenericDAO<Formando> {
    
}