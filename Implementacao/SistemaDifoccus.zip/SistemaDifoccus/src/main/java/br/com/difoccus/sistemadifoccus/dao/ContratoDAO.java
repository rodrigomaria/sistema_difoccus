package br.com.difoccus.sistemadifoccus.dao;

import br.com.difoccus.sistemadifoccus.modelo.Contrato;

public class ContratoDAO  extends  GenericDAO<Contrato> {
    
}